package com.example.url.validation.Url.validation.model;

public class UrlDto {

    private String originalUrl;

    public UrlDto() {
    }

    public UrlDto(String originalUrl) {
        this.originalUrl = originalUrl;
    }

    public String getOriginalUrl() {
        return originalUrl;
    }

    public void setOriginalUrl(String originalUrl) {
        this.originalUrl = originalUrl;
    }
}
