package com.example.url.validation.Url.validation.customException;

public class UrlCreationException extends RuntimeException{
    private static final long serialVersionUID = 1L;

    public UrlCreationException(String message) {
        super(message);
    }
}
