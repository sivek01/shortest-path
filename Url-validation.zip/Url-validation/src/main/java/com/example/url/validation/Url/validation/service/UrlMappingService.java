package com.example.url.validation.Url.validation.service;


import com.example.url.validation.Url.validation.model.UrlMapping;
import com.example.url.validation.Url.validation.repo.UrlMappingRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.Date;
import java.util.Optional;
import java.util.Random;
import java.util.concurrent.TimeUnit;

@Service
public class UrlMappingService {

    @Autowired
    private UrlMappingRepository urlMappingRepository;

    public String generateShortUrl(String originalUrl) throws Exception {
        URL url;
        try {
            System.out.println("originalUrl is "+originalUrl);
            url = new URL(originalUrl);
        } catch (MalformedURLException e) {
            throw new Exception("Invalid URL");
        }

        String shortUrl = generateRandomString();

        Optional<UrlMapping> mappingOptional = urlMappingRepository.findByOriginalUrl(originalUrl);
        if (mappingOptional.isPresent()) {
            UrlMapping urlMapping=  mappingOptional.get();
            urlMapping.setCreatedAt(new Date());
            urlMappingRepository.save(urlMapping);
            return mappingOptional.get().getShortUrl();
        }

        UrlMapping mapping = new UrlMapping();
        mapping.setOriginalUrl(originalUrl);
        mapping.setShortUrl(shortUrl);
        mapping.setCreatedAt(new Date());
        urlMappingRepository.save(mapping);

        return shortUrl;
    }

    public String getOriginalUrl(String shortUrl) throws Exception {
        Optional<UrlMapping> mappingOptional = urlMappingRepository.findByShortUrl(shortUrl);
        if (!mappingOptional.isPresent()) {
            throw new Exception("URL does not exist");
        }

        UrlMapping mapping = mappingOptional.get();
        Date createdAt = mapping.getCreatedAt();
        Date now = new Date();
        long diffInMinutes = TimeUnit.MILLISECONDS.toMinutes(now.getTime() - createdAt.getTime());
        if (diffInMinutes > 5) {
            throw new Exception("URL has expired");
        }

        return mapping.getOriginalUrl();
    }

    private String generateRandomString() {
        String characters = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        StringBuilder sb = new StringBuilder();
        Random random = new Random();
        for (int i = 0; i < 8; i++) {
            sb.append(characters.charAt(random.nextInt(characters.length())));
        }
        return sb.toString();
    }
}


