package com.example.url.validation.Url.validation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UrlValidationApplication {

	public static void main(String[] args) {
		SpringApplication.run(UrlValidationApplication.class, args);
	}

}
