package com.example.url.validation.Url.validation.controller;

import com.example.url.validation.Url.validation.service.UrlMappingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import java.util.Map;

@RestController
@RequestMapping("/api/url-mapping")
@CrossOrigin("*")
public class UrlMappingController {

    @Autowired
    private UrlMappingService urlMappingService;

    @PostMapping("/generate")
    public ResponseEntity<?> generateShortUrl(@RequestBody Map<String, String> requestBody) {
        try {
            String originalUrl = requestBody.get("originalUrl");
            String shortUrl = urlMappingService.generateShortUrl(originalUrl);
            return ResponseEntity.ok().body(Map.of("shortUrl", shortUrl));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    @GetMapping("/{shortUrl}")
    public ResponseEntity<?> redirectToOriginalUrl(@PathVariable String shortUrl, HttpServletResponse response) {
        try {
            String originalUrl = urlMappingService.getOriginalUrl(shortUrl);
            response.sendRedirect(originalUrl);
            return null;
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }
}

