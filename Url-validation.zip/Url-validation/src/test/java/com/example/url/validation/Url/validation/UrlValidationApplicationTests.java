package com.example.url.validation.Url.validation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UrlValidationApplicationTests {

	@Test
	void contextLoads() {
	}

}
